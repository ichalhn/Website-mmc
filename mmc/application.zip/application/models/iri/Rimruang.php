<?php
class Rimruang extends CI_Model {

	public function get_all_ruang(){
		$data=$this->db->query("
			select * from ruang");
		return $data->result_array();
	}
}
?>
